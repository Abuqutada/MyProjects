﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Polynomial.Command
{
    class Validations
    {
        #region Method
        public static bool isValid(String x)
        {
            return Polynomial.Command.Poly.ValidateExpression(x);

        }
        #endregion

    }
}
