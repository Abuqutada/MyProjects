﻿using System.Threading.Tasks;
using System.Windows;
using MahApps.Metro.Controls;
using MahApps.Metro.Controls.Dialogs;
using System.Windows.Controls;
namespace Polynomial.Command
{
    public  static class Write 
    {
        #region Methods
        public static async void Error(string Titel,string Message)
        {
            var metroWindow = (Application.Current.MainWindow as MetroWindow);
            MessageDialogStyle Neg = MessageDialogStyle.Affirmative;
            MetroDialogSettings ms = new MetroDialogSettings();
            ms.ColorScheme = MetroDialogColorScheme.Inverted;
            await metroWindow.ShowMessageAsync(Titel, Message,Neg,ms);

        }

        public static async void Message(string Titel, string Message)
        {
            var metroWindow = (Application.Current.MainWindow as MetroWindow);
            MessageDialogStyle Neg = MessageDialogStyle.Affirmative;
            MetroDialogSettings ms = new MetroDialogSettings();
            ms.ColorScheme = MetroDialogColorScheme.Accented;
            await metroWindow.ShowMessageAsync(Titel, Message, Neg, ms);
        }
        public async static Task<MessageDialogResult> ShowMessageAsync(string title, string Message,MessageDialogStyle style )
        {
            MetroDialogSettings settings = new MetroDialogSettings();
            settings.ColorScheme = MetroDialogColorScheme.Inverted;

            return await ((MetroWindow)(Application.Current.MainWindow)).ShowMessageAsync(title, Message, style, settings);
        }
        public async static void Messages(string message, string title)
        {
            var metroWindow = (Application.Current.MainWindow as MetroWindow);
            MessageDialogStyle Neg = MessageDialogStyle.Affirmative;

           


        }


        #endregion

    }

}
