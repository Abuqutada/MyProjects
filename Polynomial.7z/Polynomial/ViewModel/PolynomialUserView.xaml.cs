﻿using System;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Input;
using System.Windows.Media;
using MahApps.Metro.Controls;
using Polynomial.Command;
using MahApps.Metro.Controls.Dialogs;
namespace Polynomial.ViewModel
{
    /// <summary>
    /// Interaction logic for PolynomialUserView.xaml
    /// </summary>
    public partial class PolynomialUserView : UserControl
    {
        #region Fields & Properties:
        private Poly PolyVariable;
        private Poly SecondPoly;
        private bool isValidate = false;



        public bool IsValidate
        {
            get { return isValidate; }
            set { isValidate = value; }
        }
        #endregion
        #region Constructor
        public PolynomialUserView()
        {
            InitializeComponent();
        }
        #endregion

        #region Method





        private async void Validit(object sender, RoutedEventArgs e)
        {
            if (Validations.isValid(TextBoxExpressionMembers.Text))
            {
                try
                {
                    this.PolyVariable = new Polynomial.Command.Poly(this.TextBoxExpressionMembers.Text);
                    this.IsValidate = true;
                    this.TextBoxExpressionMembers.Foreground = Brushes.Black;

                }
                catch (Exception ex)
                {
                    this.TextBoxExpressionMembers.Foreground = Brushes.Red;
                    this.IsValidate = false;
                    Write.Error("Exception", ex.Message);
                }
            }
            else
            {


                var res = await Write.ShowMessageAsync("Error", "The Expression one is empty do you like to fil it Randomly ", MessageDialogStyle.AffirmativeAndNegative);
                if (res == MessageDialogResult.Affirmative)
                {
                    this.PolyVariable = new Poly();
                    TextBoxExpressionMembers.Text = this.PolyVariable.ToString();
                    this.isValidate = true;
                    this.TextBoxExpressionMembers.Foreground = Brushes.Black;
                    Validit(sender, e);
                }
                else
                {
                    this.TextBoxExpressionMembers.Foreground = Brushes.Red;
                    this.IsValidate = false;
                }
            }
        }

        private async void Validit2(object sender, RoutedEventArgs e)
        {
            if (Validations.isValid(TextBoxExpressionMembers2.Text))
            {
                try
                {
                    String x = this.TextBoxExpressionMembers2.Text;
                    this.SecondPoly = new Polynomial.Command.Poly(this.TextBoxExpressionMembers2.Text);


                    this.IsValidate = true;

                    this.TextBoxExpressionMembers2.Foreground = Brushes.Black;

                }
                catch (Exception ex)
                {
                    this.TextBoxExpressionMembers2.Foreground = Brushes.Red;
                    this.IsValidate = false;

                }
            }
            else
            {

                var res = await Write.ShowMessageAsync("Error", "The Expression Two is empty do you like to fil it Randomly ", MessageDialogStyle.AffirmativeAndNegative);
                if (res == MessageDialogResult.Affirmative)
                {
                    this.PolyVariable = new Poly();
                    TextBoxExpressionMembers2.Text = this.PolyVariable.ToString();
                    this.isValidate = true;
                    this.TextBoxExpressionMembers2.Foreground = Brushes.Black;
                    Validit(sender, e);
                }
                else
                {
                    this.TextBoxExpressionMembers2.Foreground = Brushes.Red;
                    this.IsValidate = false;
                }

            }
        }



        private void Plus(object sender, RoutedEventArgs e)
        {


            if (IsValidate)
            {
                if (SecondPoly == null)
                    SecondPoly = new Polynomial.Command.Poly(this.TextBoxExpressionMembers2.Text);

                Polynomial.Command.Poly result;
                switch ((sender as Button).Content.ToString())
                {
                    case "Plus":
                        result = this.PolyVariable + SecondPoly;
                        Write.Message("The Answer is :", result.ToString());

                        break;
                    case "Minus":
                        result = this.PolyVariable - SecondPoly;
                        Write.Message("The Answer is :", result.ToString());

                        break;
                    case "Multiply":
                        result = this.PolyVariable * SecondPoly;
                        Write.Message("The Answer is :", result.ToString());

                        break;
                    case "Divide":
                        Write.Error("Exception", "wait i will do it ^_^");
                        break;
                    case "Pluslus":
                        result = SecondPoly++;
                        Write.Message("The Answer is :", result.ToString());

                        break;
                    case "MinusMinus":
                        result = SecondPoly--;
                        Write.Message("The Answer is :", result.ToString());

                        break;
                    default:
                        result = new Polynomial.Command.Poly("-1");
                        break;
                }

            }
            else
            {
                Write.Error("Error", "Invalid Poly Variables");
            }



        }


        private void Minus(object sender, RoutedEventArgs e)
        {
            Plus(sender, e);
        }

        private void Multiply(object sender, RoutedEventArgs e)
        {
            Plus(sender, e);

        }


        private void Edit(object sender, RoutedEventArgs e)
        {
            try
            {
                if (checkBox1.IsChecked == true)
                {
                    #region Poly1
                    Term _t = new Term(edittext1.Text);
                    bool flag = false;
                    TermCollection _T = new TermCollection();
                    foreach (Term t in PolyVariable.Terms)
                    {
                        _T.Add(t);
                    }
                    bool x = _T.Contatins(_t);
                    if (!x)
                    {
                        foreach (Term t in _T)
                        {

                            if (t.Power == _t.Power)
                            {
                                flag = true;
                                _T.Remove(t);
                                _T.Add(_t);
                                break;
                            }
                        }
                        if (!flag)
                        {
                            _T.Add(_t);
                        }
                    }
                    this.PolyVariable = new Poly(_T);
                    TextBoxExpressionMembers.Text = PolyVariable.ToString();
                }
                #endregion
                if (checkBox2.IsChecked == true)
                {
                    #region Poly2
                    Term _t = new Term(edittext2.Text);
                    bool flag = false;
                    TermCollection _T = new TermCollection();
                    foreach (Term t in SecondPoly.Terms)
                    {
                        _T.Add(t);
                    }
                    bool x = _T.Contatins(_t);
                    if (!x)
                    {
                        foreach (Term t in _T)
                        {

                            if (t.Power == _t.Power)
                            {
                                flag = true;
                                _T.Remove(t);
                                _T.Add(_t);
                                break;
                            }
                        }
                        if (!flag)
                        {
                            _T.Add(_t);
                        }
                    }
                    this.SecondPoly = new Poly(_T);
                    TextBoxExpressionMembers2.Text = SecondPoly.ToString();
                }
                #endregion
            }
            catch(Exception ex)
            {
                Write.Error("Exception", ex.Message);
            }
        }




        #endregion

    }
}

